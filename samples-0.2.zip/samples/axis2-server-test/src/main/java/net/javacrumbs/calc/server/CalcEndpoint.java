/**
 * Copyright 2009-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.javacrumbs.calc.server;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(serviceName="CalculatorService", targetNamespace="http://javacrumbs.net/calc")
public class CalcEndpoint {

	private static final String NS = "http://javacrumbs.net/calc";

	@WebMethod
	@WebResult(name="result",targetNamespace=NS)
	public long plus(@WebParam(name="a",targetNamespace=NS) long a, @WebParam(name="b",targetNamespace=NS) long b)
	{
		if (a+b>Integer.MAX_VALUE)
		{
			throw new IllegalArgumentException("Values are too big.");
		}
		return a+b;
	}
}
